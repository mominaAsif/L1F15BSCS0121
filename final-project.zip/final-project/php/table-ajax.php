<html>
<head>
	<meta charset="UTF-8">
	<title> Your Order </title>
	<link rel="stylesheet" href="css/bootstrap.css">
	<link rel="stylesheet" href="css/style.css">
</head>

<body id="home">
<?php
    echo ' <nav class="navbar navbar-expand-md navbar-light"> ' ; 
        echo ' <div class="container">' ;  
           echo ' <a href="main.html" class="navbar-brand">' ; 
                echo '<h3 class="d-inline align-middle"> Auto Motors </h3>' ; 
            echo '</a>' ; 
            echo '<button class="navbar-toggler" data-toggle="collapse" data-target="#navbarNav"><span class="navbar-toggler-icon"></span></button>' ; 
            echo '<div class="collapse navbar-collapse" id="navbarNav"> ' ; 
               echo ' <ul class="navbar-nav ml-auto">' ; 
                    echo '<li class="nav-item"> ';
                        echo '<a href="main.html" class="nav-link">Home</a>' ; 
                    echo '</li>' ; 
                    echo '<li class="nav-item">' ; 
                       echo ' <a href="cardetails.html" class="nav-link">Cars Details</a>' ; 
                   echo ' </li>' ; 
                echo '</ul>' ; 
            echo '</div>' ; 
        echo '</div>' ; 
    echo '</nav>' ; 

?>
</body>
</html>
</body>
</html>