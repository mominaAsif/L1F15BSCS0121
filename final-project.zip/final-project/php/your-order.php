<html>
<head>
	<meta charset="UTF-8">
	<title> Your Order </title>
	<link rel="stylesheet" href="css/bootstrap.css">
	<link rel="stylesheet" href="css/style.css">
</head>

<body id="home">
    <nav class="navbar navbar-expand-md navbar-light">
        <div class="container">
            <a href="main.html" class="navbar-brand">
                <h3 class="d-inline align-middle"> Auto Motors </h3>
            </a>
            <button class="navbar-toggler" data-toggle="collapse" data-target="#navbarNav"><span class="navbar-toggler-icon"></span></button>
            <div class="collapse navbar-collapse" id="navbarNav">
                <ul class="navbar-nav ml-auto">
                    <li class="nav-item">
                        <a href="main.html" class="nav-link">Home</a>
                    </li>
                    <li class="nav-item">
                        <a href="cardetails.html" class="nav-link">Cars Details</a>
                    </li>
                </ul>
            </div>
        </div>
    </nav>
    <section id="join" class="bg-light py-4">
        <div class="container-fluid">
            <div class="row">
                <div class="col-sm-12 col-lg-8 col-xl-8">
				
					<div class="col-sm-6 col-lg-4 col-xl-4"  id = "m1" >
						<!---Add pic here--->
						<img src="images/image3.jpg" /> 
					</div > 
					<div class="col-sm-6 col-lg-4 col-xl-4"  id = "m2" >
						<!---mission and vision here--->
						<div class="py-5" >
							<h3>Our Vision  </h3>
							<p class="lead">Description here.</p>
						</div>
						
						<div class="py-5 ">
							<h3>Our Mission  </h3>
							<p class="lead">Description here.</p>
						</div>
					</div> 
                </div>
               
            </div>
        </div>
    </section>

<footer id="main-footer" class="py-5  text-white" >
    <div class="container">
        <div class="row text-center">
            <div class="col-md-6 ml-auto">
                <p class="lead">Copyright &copy; 2018</p>
            </div>
        </div>
    </div>
</footer>

</body>
</html>
</body>
</html>